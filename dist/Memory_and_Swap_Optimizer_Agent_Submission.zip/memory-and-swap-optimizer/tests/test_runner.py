"""Command runner: fixed executables, no shell, injection blocking, timeouts and output limits."""

import os
import shutil

import pytest

from mso_agent.execution import runner
from mso_agent.security import blacklist


@pytest.fixture
def fake_paths(monkeypatch):
    """Pretend every fixed executable exists so argv building can be tested on any host."""
    monkeypatch.setattr(runner, "_first_existing", lambda paths: paths[0])


def test_unknown_command_rejected():
    with pytest.raises(runner.CommandRejected, match="fixed command table"):
        runner.build_argv("bash", ["-c", "id"])


@pytest.mark.parametrize("arg", [
    "cron.service; reboot", "cron.service && id", "$(id).service", "`id`", "cron.service | sh",
    "--now", "-r", "a\x00b", "",
])
def test_injection_arguments_rejected(fake_paths, arg):
    with pytest.raises(runner.CommandRejected):
        runner.build_argv("systemctl_restart", [arg])


def test_too_many_args_rejected(fake_paths):
    with pytest.raises(runner.CommandRejected):
        runner.build_argv("modinfo", ["a", "b"])


@pytest.mark.parametrize("arg,ok", [
    ("vm.swappiness=30", True), ("vm.swappiness=10", True), ("vm.swappiness=100", True),
    ("vm.swappiness=5", False), ("vm.swappiness=101", False), ("vm.swappiness=-1", False),
    ("vm.drop_caches=3", True), ("vm.drop_caches=4", False),
    ("kernel.panic=1", False), ("vm.overcommit_memory=2", False), ("vm.swappiness=30 ", False),
])
def test_sysctl_setter_is_tightly_bounded(fake_paths, arg, ok):
    if ok:
        argv = runner.build_argv("sysctl_set", [arg])
        assert argv == ["/usr/bin/sudo", "-n", "/usr/sbin/sysctl", "-w", arg]
    else:
        with pytest.raises(runner.CommandRejected):
            runner.build_argv("sysctl_set", [arg])


def test_privileged_commands_use_sudo_non_interactive(fake_paths):
    argv = runner.build_argv("systemctl_restart", ["cron.service"])
    assert argv[:2] == ["/usr/bin/sudo", "-n"]     # -n: never prompt, never read a password
    assert runner.build_argv("modinfo", ["loop"])[0] == "/usr/sbin/modinfo"   # read-only: no sudo


def test_missing_executable_reported():
    spec = runner.COMMANDS["modinfo"]
    runner.COMMANDS["modinfo"] = runner.CommandSpec("modinfo", ("/nonexistent/modinfo",), (), spec.arg_validator)
    try:
        with pytest.raises(runner.CommandUnavailable):
            runner.build_argv("modinfo", ["loop"])
    finally:
        runner.COMMANDS["modinfo"] = spec


def test_dry_run_does_not_execute(fake_paths, monkeypatch):
    called = []
    monkeypatch.setattr(runner, "run_argv", lambda *a, **k: called.append(a))
    res = runner.run_command("sysctl_set", ["vm.swappiness=30"], dry_run=True)
    assert res.dry_run and not called and res.argv[-1] == "vm.swappiness=30"


def test_shell_false_treats_metacharacters_literally():
    echo = shutil.which("echo") or "/bin/echo"
    res = runner.run_argv([echo, "hello; touch /tmp/mso_pwned"], timeout_s=5)
    assert res.stdout.strip() == "hello; touch /tmp/mso_pwned"
    assert not os.path.exists("/tmp/mso_pwned")


def test_timeout_kills_process():
    res = runner.run_argv(["/bin/sleep", "10"], timeout_s=0.5)
    assert res.timed_out and res.returncode is None and res.duration_s < 5


def test_output_limit_bounds_memory():
    yes = shutil.which("yes") or "/usr/bin/yes"
    res = runner.run_argv([yes], timeout_s=1.0, output_limit=1024)
    assert res.truncated and len(res.stdout) <= 1024 and res.timed_out


def test_environment_is_minimal(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "sk-should-not-leak-123456")
    env_bin = shutil.which("env") or "/usr/bin/env"
    res = runner.run_argv([env_bin], timeout_s=5)
    assert "OPENAI_API_KEY" not in res.stdout
    assert "PATH=/usr/sbin:/usr/bin:/sbin:/bin" in res.stdout


@pytest.mark.parametrize("text,hit", [
    ("rm -rf /", True), ("mkfs.ext4 /dev/sda1", True), ("dd if=/dev/zero of=/dev/sda", True),
    (":(){ :|:& };:", True), ("echo x > /dev/sda", True), ("swapoff -a", True), ("kill -9 1", True),
    ("sysctl -w vm.swappiness=30", False), ("systemctl restart cron.service", False),
])
def test_supplementary_blacklist(text, hit):
    assert (blacklist.screen_text(text) is not None) == hit


def test_blacklist_flags_metacharacters_per_argument():
    assert blacklist.screen_argv(["/usr/bin/systemctl", "restart", "a;b"]) is not None
    assert blacklist.screen_argv(["/usr/bin/systemctl", "restart", "cron.service"]) is None
