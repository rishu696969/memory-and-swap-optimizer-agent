import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))


@pytest.fixture
def anyio_backend():
    return "asyncio"


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    """Isolated data dir + allowed root for every test that touches settings."""
    d = tmp_path / "data"
    d.mkdir()
    allowed = tmp_path / "allowed"
    allowed.mkdir()
    monkeypatch.setenv("MSO_DATA_DIR", str(d))
    monkeypatch.setenv("MSO_ALLOWED_ROOTS", str(allowed))
    monkeypatch.delenv("MSO_DRY_RUN", raising=False)
    return d


@pytest.fixture
def allowed_root(data_dir):
    return Path(os.environ["MSO_ALLOWED_ROOTS"])


IS_LINUX = sys.platform.startswith("linux")
linux_only = pytest.mark.skipif(not IS_LINUX, reason="needs Linux /proc")
