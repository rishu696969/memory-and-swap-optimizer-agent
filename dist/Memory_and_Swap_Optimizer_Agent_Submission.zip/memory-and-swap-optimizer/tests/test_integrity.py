"""File integrity: SHA-256 hashing and baseline comparison."""

import hashlib
import os

import pytest

from mso_agent.tools import integrity


def test_sha256_matches_hashlib(tmp_path):
    f = tmp_path / "a.txt"
    f.write_bytes(b"hello world\n" * 100_000)
    assert integrity.sha256_file(f) == hashlib.sha256(f.read_bytes()).hexdigest()


def test_known_vector(tmp_path):
    f = tmp_path / "abc"
    f.write_bytes(b"abc")
    assert integrity.sha256_file(f) == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"


def test_compare_pure():
    base = {"a": {"sha256": "1"}, "b": {"sha256": "2"}, "c": {"sha256": "3"}}
    cur = {"a": {"sha256": "1"}, "b": {"sha256": "X"}, "d": {"sha256": "4"}}
    assert integrity.compare(base, cur) == {"modified": ["b"], "missing": ["c"], "new": ["d"]}


def test_baseline_roundtrip_reports_changes(tmp_path):
    root, store = tmp_path / "tree", tmp_path / "store"
    (root / "sub").mkdir(parents=True)
    (root / "keep.txt").write_text("same")
    (root / "edit.txt").write_text("v1")
    (root / "sub" / "gone.txt").write_text("bye")
    created = integrity.create_baseline(root, store)
    assert created["file_count"] == 3
    assert integrity.verify_baseline(root, store).status == "unchanged"

    (root / "edit.txt").write_text("v2")
    (root / "sub" / "gone.txt").unlink()
    (root / "added.txt").write_text("new")
    rep = integrity.verify_baseline(root, store)
    assert rep.modified == ["edit.txt"]
    assert rep.missing == [os.path.join("sub", "gone.txt")]
    assert rep.new == ["added.txt"]
    assert rep.unchanged_count == 1


def test_symlinks_not_followed(tmp_path):
    root, outside, store = tmp_path / "tree", tmp_path / "outside", tmp_path / "store"
    root.mkdir()
    outside.mkdir()
    (outside / "secret").write_text("s")
    os.symlink(outside / "secret", root / "link_to_secret")
    os.symlink(outside, root / "link_dir")
    created = integrity.create_baseline(root, store)
    assert created["file_count"] == 0
    assert any("link_to_secret" in s for s in created["skipped"])
    assert any("link_dir" in s for s in created["skipped"])


def test_verify_without_baseline(tmp_path):
    (tmp_path / "t").mkdir()
    with pytest.raises(FileNotFoundError):
        integrity.verify_baseline(tmp_path / "t", tmp_path / "store")


def test_replacement_is_described(tmp_path):
    root, store = tmp_path / "tree", tmp_path / "store"
    root.mkdir()
    summary, _ = integrity.describe_baseline(root, store)
    assert summary.startswith("Create")
    integrity.create_baseline(root, store)
    summary, details = integrity.describe_baseline(root, store)
    assert summary.startswith("REPLACE") and "replaces_baseline_created_at" in details


def test_file_limit(tmp_path, monkeypatch):
    root = tmp_path / "many"
    root.mkdir()
    for i in range(5):
        (root / f"f{i}").write_text(str(i))
    with pytest.raises(ValueError, match="more than"):
        integrity.scan_directory(root, max_files=3)
