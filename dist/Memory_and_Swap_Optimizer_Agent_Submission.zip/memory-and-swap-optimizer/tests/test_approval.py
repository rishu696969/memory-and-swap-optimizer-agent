"""Approval gate: approvals are verified at the execution boundary and scoped to one exact operation."""

import secrets

import pytest

from mso_agent.security.approval import ApprovalError, ApprovalGate, compute_token

KEY = secrets.token_bytes(32)


def make(gate, value=30):
    return gate.create("set_swappiness", {"value": value}, "set swappiness", {})


def token_for(op, key=KEY, **override):
    args = override.get("args", op.args)
    return compute_token(key, override.get("op_id", op.op_id), override.get("action", op.action), args, op.nonce)


def test_valid_token_consumes_once():
    gate = ApprovalGate(KEY)
    op = make(gate)
    assert gate.consume(op.op_id, token_for(op)).args == {"value": 30}
    with pytest.raises(ApprovalError, match="already used|unknown"):
        gate.consume(op.op_id, token_for(op))          # replay is refused


def test_wrong_key_rejected():
    gate = ApprovalGate(KEY)
    op = make(gate)
    with pytest.raises(ApprovalError, match="not valid"):
        gate.consume(op.op_id, token_for(op, key=secrets.token_bytes(32)))


def test_token_scoped_to_arguments():
    gate = ApprovalGate(KEY)
    op = make(gate, 60)
    forged = token_for(op, args={"value": 10})          # approve 10 but stored op is 60
    with pytest.raises(ApprovalError):
        gate.consume(op.op_id, forged)


def test_token_scoped_to_operation():
    gate = ApprovalGate(KEY)
    a, b = make(gate, 30), make(gate, 30)
    with pytest.raises(ApprovalError):
        gate.consume(b.op_id, token_for(a))             # token for op A does not unlock op B
    assert gate.consume(a.op_id, token_for(a))


@pytest.mark.parametrize("bad", ["", "yes", "approved", "0" * 64, None, 123])
def test_model_style_tokens_rejected(bad):
    gate = ApprovalGate(KEY)
    op = make(gate)
    with pytest.raises(ApprovalError):
        gate.consume(op.op_id, bad)
    # the failed attempt did not consume the legitimate request
    assert gate.consume(op.op_id, token_for(op))


def test_expiry():
    now = [1000.0]
    gate = ApprovalGate(KEY, ttl_seconds=60, clock=lambda: now[0])
    op = make(gate)
    now[0] += 61
    with pytest.raises(ApprovalError, match="expired|unknown"):
        gate.consume(op.op_id, token_for(op))


def test_cancel():
    gate = ApprovalGate(KEY)
    op = make(gate)
    assert gate.cancel(op.op_id)
    with pytest.raises(ApprovalError):
        gate.consume(op.op_id, token_for(op))


def test_public_view_has_no_secret():
    gate = ApprovalGate(KEY)
    view = make(gate).public_view()
    assert KEY.hex() not in str(view)
    assert view["status"] == "approval_required"


def test_short_key_refused():
    with pytest.raises(ValueError):
        ApprovalGate(b"short")
