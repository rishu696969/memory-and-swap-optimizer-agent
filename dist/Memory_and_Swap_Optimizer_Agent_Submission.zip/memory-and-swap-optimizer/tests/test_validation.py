"""Strict argument validation: the main argument boundary of the MCP server."""

import os

import pytest

from mso_agent.security.validation import (
    ValidationError,
    validate_arguments,
    validate_directory,
    validate_module_name,
    validate_service_name,
)


def test_unknown_tool_rejected():
    with pytest.raises(ValidationError, match="unknown tool"):
        validate_arguments("run_shell", {"cmd": "rm -rf /"})


@pytest.mark.parametrize("flag", ["approved", "confirm", "human_approved", "approval_token"])
def test_model_supplied_approval_flag_rejected(flag):
    # A model cannot smuggle an approval flag into a request_* tool.
    with pytest.raises(ValidationError, match="unknown argument"):
        validate_arguments("request_swappiness_change", {"value": 30, flag: True})


@pytest.mark.parametrize("bad", ["30", 30.0, True, None, [30], {"v": 30}])
def test_swappiness_requires_real_int(bad):
    with pytest.raises(ValidationError):
        validate_arguments("request_swappiness_change", {"value": bad})


@pytest.mark.parametrize("value", [-1, 0, 9, 101, 200, 10**9])
def test_swappiness_bounds(value):
    with pytest.raises(ValidationError):
        validate_arguments("request_swappiness_change", {"value": value})


@pytest.mark.parametrize("value", [10, 60, 100])
def test_swappiness_accepts_bounds(value):
    assert validate_arguments("request_swappiness_change", {"value": value}) == {"value": value}


def test_drop_caches_choices():
    assert validate_arguments("request_drop_caches", {"level": 3}) == {"level": 3}
    for bad in (0, 4, "3"):
        with pytest.raises(ValidationError):
            validate_arguments("request_drop_caches", {"level": bad})


def test_sampling_limits_and_float_coercion():
    ok = validate_arguments("sample_process_memory", {"samples": 5, "interval_seconds": 1})
    assert ok["interval_seconds"] == 1.0 and isinstance(ok["interval_seconds"], float)
    for args in ({"samples": 2}, {"samples": 31}, {"interval_seconds": 0.0}, {"interval_seconds": float("nan")}):
        with pytest.raises(ValidationError):
            validate_arguments("sample_process_memory", args)


def test_control_characters_rejected():
    with pytest.raises(ValidationError, match="control"):
        validate_arguments("get_service_status", {"service": "cron\n.service"})


def test_arguments_must_be_object():
    with pytest.raises(ValidationError):
        validate_arguments("get_memory_stats", ["not", "a", "dict"])


@pytest.mark.parametrize("name", ["uvcvideo", "snd-dummy", "SND_DUMMY".lower()])
def test_module_name_ok(name):
    assert validate_module_name(name) == name.replace("-", "_")


@pytest.mark.parametrize("name", ["uvcvideo; rm -rf /", "../evil", "-r", "a b", "x" * 60, "$(id)", ""])
def test_module_name_injection(name):
    with pytest.raises(ValidationError):
        validate_module_name(name)


def test_module_allowlist():
    assert validate_module_name("snd-dummy", ["snd_dummy"]) == "snd_dummy"
    with pytest.raises(ValidationError, match="allowlist"):
        validate_module_name("ext4", ["snd_dummy"])


def test_service_name_rules():
    assert validate_service_name("cron") == "cron.service"
    assert validate_service_name("getty@tty1.service") == "getty@tty1.service"
    for bad in ("--now.service", "cron;reboot", "cron.service; rm", "$(reboot).service", "a/b.service"):
        with pytest.raises(ValidationError):
            validate_service_name(bad)
    with pytest.raises(ValidationError, match="allowlist"):
        validate_service_name("ssh.service", ["cron.service"])


def test_directory_inside_allowed_root(allowed_root):
    sub = allowed_root / "project"
    sub.mkdir()
    assert validate_directory(str(sub), [str(allowed_root)]) == sub.resolve()


def test_directory_traversal_rejected(allowed_root, tmp_path):
    outside = tmp_path / "outside"
    outside.mkdir()
    with pytest.raises(ValidationError, match="outside"):
        validate_directory(str(allowed_root / ".." / "outside"), [str(allowed_root)])


def test_symlink_escape_rejected(allowed_root, tmp_path):
    outside = tmp_path / "secret"
    outside.mkdir()
    link = allowed_root / "link"
    os.symlink(outside, link)
    with pytest.raises(ValidationError, match="outside"):
        validate_directory(str(link), [str(allowed_root)])


@pytest.mark.parametrize("path", ["relative/dir", "", "/proc", "/sys/kernel", "/dev"])
def test_bad_directories(path, allowed_root):
    with pytest.raises(ValidationError):
        validate_directory(path, ["/"])
