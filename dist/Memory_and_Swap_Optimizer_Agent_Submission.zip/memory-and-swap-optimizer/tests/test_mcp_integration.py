"""End-to-end over a REAL MCP stdio connection: client -> server subprocess -> tools.

These tests start `python -m mso_agent.server` exactly as the REPL does.
Privileged execution is forced into dry-run mode, so nothing on the host changes.
"""

import json
import secrets

import pytest

from mso_agent.audit import AuditLogger
from mso_agent.orchestration.agent import Agent
from mso_agent.orchestration.demo_router import DemoRouter
from mso_agent.orchestration.mcp_client import ToolServerConnection
from mso_agent.orchestration.providers import ToolCall
from mso_agent.security.approval import compute_token

pytestmark = pytest.mark.anyio


def approver(answer: bool, seen: list):
    async def _ask(req):
        seen.append(req)
        return answer
    return _ask


@pytest.fixture
def env(data_dir, monkeypatch):
    monkeypatch.setenv("MSO_DRY_RUN", "1")
    return data_dir


async def test_tools_are_discovered_with_schemas(env):
    async with ToolServerConnection(secrets.token_bytes(32)) as conn:
        names = {t.name for t in conn.tools}
        assert {"get_memory_stats", "sample_process_memory", "request_swappiness_change",
                "verify_file_baseline", "list_kernel_modules", "get_service_status"} <= names
        swp = next(t for t in conn.tools if t.name == "request_swappiness_change")
        assert swp.input_schema["properties"]["value"]["minimum"] == 10
        assert next(t for t in conn.tools if t.name == "get_memory_stats").read_only


async def test_read_only_tool_returns_structured_data(env):
    async with ToolServerConnection(secrets.token_bytes(32)) as conn:
        out = await conn.call("get_memory_stats", {})
        assert out.ok and out.data["total_mb"] > 0 and out.data["pressure_level"] in ("low", "moderate", "high")


async def test_server_rejects_injected_approval_flag(env):
    async with ToolServerConnection(secrets.token_bytes(32)) as conn:
        out = await conn.call("request_swappiness_change", {"value": 30, "approved": True})
        assert not out.ok and "unknown argument" in out.error
        out = await conn.call("request_swappiness_change", {"value": "30"})
        assert not out.ok and "must be int" in out.error


async def test_forged_and_replayed_tokens_refused_at_server(env):
    key = secrets.token_bytes(32)
    async with ToolServerConnection(key) as conn:
        req = (await conn.call("request_swappiness_change", {"value": 40})).data
        assert req["status"] == "approval_required"
        bad = await conn.call("apply_approved_change", {"op_id": req["op_id"], "approval_token": "yes"})
        assert not bad.ok and "execution refused" in bad.error
        wrong_key = compute_token(secrets.token_bytes(32), req["op_id"], req["action"], req["arguments"], req["nonce"])
        assert not (await conn.call("apply_approved_change", {"op_id": req["op_id"], "approval_token": wrong_key})).ok
        good = compute_token(key, req["op_id"], req["action"], req["arguments"], req["nonce"])
        ok = await conn.call("apply_approved_change", {"op_id": req["op_id"], "approval_token": good})
        assert ok.ok and ok.data["status"] == "dry_run"
        assert ok.data["result"]["command"]["argv"][-1] == "vm.swappiness=40"
        replay = await conn.call("apply_approved_change", {"op_id": req["op_id"], "approval_token": good})
        assert not replay.ok


async def test_server_without_key_fails_closed(env, monkeypatch):
    # Start a server whose key differs from the one the client uses to sign.
    conn = ToolServerConnection(secrets.token_bytes(32))
    conn.params.env["MSO_APPROVAL_KEY"] = "not-hex"
    async with conn:
        req = (await conn.call("request_drop_caches", {"level": 1})).data
        token = compute_token(secrets.token_bytes(32), req["op_id"], req["action"], req["arguments"], req["nonce"])
        assert not (await conn.call("apply_approved_change", {"op_id": req["op_id"], "approval_token": token})).ok


async def test_agent_approval_flow_approved(env):
    key, seen = secrets.token_bytes(32), []
    audit = AuditLogger(env / "audit.jsonl", "test")
    async with ToolServerConnection(key) as conn:
        agent = Agent(conn, DemoRouter(), approver(True, seen), key, audit)
        turn = await agent.handle("set swappiness to 35")
        assert seen and seen[0]["arguments"] == {"value": 35}
        assert turn.steps[0].approval == "approved" and turn.steps[0].data["status"] == "dry_run"
        assert "demo routing" in turn.text
    events = [json.loads(line)["event"] for line in (env / "audit.jsonl").read_text().splitlines()]
    assert "approval_decision" in events and "approval_verified" in events and "change_finished" in events


async def test_agent_approval_flow_denied(env):
    key, seen = secrets.token_bytes(32), []
    async with ToolServerConnection(key) as conn:
        agent = Agent(conn, DemoRouter(), approver(False, seen), key, AuditLogger(env / "a.jsonl", "t"))
        turn = await agent.handle("set swappiness to 35")
        assert turn.steps[0].approval == "denied" and turn.steps[0].data["status"] == "denied_by_user"
    server_log = (env / "audit.jsonl").read_text()     # the server writes to the shared audit log
    assert "change_cancelled" in server_log and "approval_verified" not in server_log
    assert '"approved": false' in (env / "a.jsonl").read_text()


async def test_model_cannot_call_host_only_tool(env):
    key = secrets.token_bytes(32)
    async with ToolServerConnection(key) as conn:
        agent = Agent(conn, DemoRouter(), approver(True, []), key, AuditLogger(env / "a.jsonl", "t"))
        assert "apply_approved_change" not in {t.name for t in agent.model_tools}
        step = await agent.execute_tool_call(ToolCall("x", "apply_approved_change", {"op_id": "op-1", "approval_token": "a"}))
        assert not step.ok and "host-only" in step.error
        step = await agent.execute_tool_call(ToolCall("y", "run_shell", {"cmd": "id"}))
        assert not step.ok and "unknown tool" in step.error


async def test_baseline_creation_requires_approval_then_verify(env, allowed_root):
    (allowed_root / "a.txt").write_text("one")
    key, seen = secrets.token_bytes(32), []
    async with ToolServerConnection(key) as conn:
        # Before approval: verify fails because no baseline exists
        assert not (await conn.call("verify_file_baseline", {"directory": str(allowed_root)})).ok
        agent = Agent(conn, DemoRouter(), approver(True, seen), key, AuditLogger(env / "a.jsonl", "t"))
        turn = await agent.handle(f"create a baseline for {allowed_root}")
        assert turn.steps[0].data["status"] == "executed"
        (allowed_root / "a.txt").write_text("two")
        (allowed_root / "b.txt").write_text("new")
        rep = await conn.call("verify_file_baseline", {"directory": str(allowed_root)})
        assert rep.data["modified"] == ["a.txt"] and rep.data["new"] == ["b.txt"]


async def test_directory_outside_allowed_root_rejected(env):
    async with ToolServerConnection(secrets.token_bytes(32)) as conn:
        out = await conn.call("request_baseline_creation", {"directory": "/etc"})
        assert not out.ok and "outside the allowed roots" in out.error


async def test_non_allowlisted_module_and_service_rejected(env):
    async with ToolServerConnection(secrets.token_bytes(32)) as conn:
        m = await conn.call("request_module_action", {"module": "ext4", "action": "unload"})
        s = await conn.call("request_service_action", {"service": "ssh.service", "action": "restart"})
        assert "allowlist" in m.error and "allowlist" in s.error
