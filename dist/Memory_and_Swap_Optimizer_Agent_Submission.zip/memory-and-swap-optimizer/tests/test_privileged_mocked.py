"""Privileged operations tested with mocks (no root, no sudo, no real kernel change).

subprocess execution is replaced by a recorder, so these tests prove the exact
argv that WOULD run and how failures are reported.  Live execution of modprobe
and systemctl was not verified (see the report's verification matrix).
"""

import pytest

from mso_agent.execution import runner
from mso_agent.tools import kernel_modules, services, swap


class Recorder:
    def __init__(self, returncode=0, stderr=""):
        self.calls, self.returncode, self.stderr = [], returncode, stderr

    def __call__(self, argv, timeout_s, output_limit=0, key=""):
        self.calls.append(argv)
        return runner.CommandResult(key=key, argv=argv, returncode=self.returncode, stdout="", stderr=self.stderr)


@pytest.fixture
def rec(monkeypatch):
    monkeypatch.setattr(runner, "_first_existing", lambda paths: paths[0])
    r = Recorder()
    monkeypatch.setattr(runner, "run_argv", r)
    return r


def test_swappiness_change_argv_and_restore_hint(rec, monkeypatch):
    values = iter([60, 30])
    monkeypatch.setattr(swap, "read_int", lambda path: next(values))
    out = swap.execute_swappiness_change(30, dry_run=False)
    assert rec.calls == [["/usr/bin/sudo", "-n", "/usr/sbin/sysctl", "-w", "vm.swappiness=30"]]
    assert out["success"] and out["verified"]
    assert out["restore_instructions"] == "sudo sysctl -w vm.swappiness=60"


def test_swappiness_out_of_range_never_runs(rec):
    with pytest.raises(ValueError):
        swap.execute_swappiness_change(5, dry_run=False)
    assert rec.calls == []


def test_sudo_password_required_is_reported_not_prompted(monkeypatch):
    monkeypatch.setattr(runner, "_first_existing", lambda paths: paths[0])
    monkeypatch.setattr(runner, "run_argv", Recorder(1, "sudo: a password is required"))
    monkeypatch.setattr(swap, "read_int", lambda path: 60)
    out = swap.execute_swappiness_change(30, dry_run=False)
    assert out["success"] is False and "password is required" in out["command"]["stderr"]
    assert out["verified"] is False


def test_drop_caches_runs_sync_first(rec):
    out = swap.execute_drop_caches(1, dry_run=False)
    assert rec.calls[0] == ["/usr/bin/sync"]
    assert rec.calls[1] == ["/usr/bin/sudo", "-n", "/usr/sbin/sysctl", "-w", "vm.drop_caches=1"]
    assert "NOT evidence of better performance" in out["note"]


def test_module_reload_sequence(rec, monkeypatch):
    monkeypatch.setattr(kernel_modules, "list_modules", lambda f=None: kernel_modules.ModuleList(
        available=True, count=0, modules=[]))
    out = kernel_modules.execute_action("uvcvideo", "reload", dry_run=False)
    assert rec.calls == [
        ["/usr/bin/sudo", "-n", "/usr/sbin/modprobe", "-r", "uvcvideo"],
        ["/usr/bin/sudo", "-n", "/usr/sbin/modprobe", "uvcvideo"],
    ]
    assert out["success"]


def test_module_reload_stops_if_unload_fails(monkeypatch):
    monkeypatch.setattr(runner, "_first_existing", lambda paths: paths[0])
    r = Recorder(1, "modprobe: FATAL: Module uvcvideo is in use.")
    monkeypatch.setattr(runner, "run_argv", r)
    monkeypatch.setattr(kernel_modules, "list_modules", lambda f=None: kernel_modules.ModuleList(
        available=True, count=0, modules=[]))
    out = kernel_modules.execute_action("uvcvideo", "reload", dry_run=False)
    assert len(r.calls) == 1 and out["success"] is False


def test_service_restart_and_enable(rec):
    services.execute_action("cron.service", "restart", dry_run=False)
    services.execute_action("cron.service", "enable", dry_run=False)
    privileged = [c for c in rec.calls if c[0] == "/usr/bin/sudo"]
    assert privileged == [
        ["/usr/bin/sudo", "-n", "/usr/bin/systemctl", "restart", "cron.service"],
        ["/usr/bin/sudo", "-n", "/usr/bin/systemctl", "enable", "cron.service"],
    ]


def test_service_status_is_unprivileged(rec):
    services.service_status("cron.service")
    assert rec.calls[0][:2] == ["/usr/bin/systemctl", "show"]


def test_unsupported_actions_have_no_mapping():
    # stop/disable/mask are not in the command table at all
    for key in ("systemctl_stop", "systemctl_disable", "systemctl_mask", "swapoff", "kill"):
        assert key not in runner.COMMANDS


def test_dry_run_records_nothing(rec):
    out = services.execute_action("cron.service", "restart", dry_run=True)
    assert out["executed"] is False and not any(c[0] == "/usr/bin/sudo" for c in rec.calls)
