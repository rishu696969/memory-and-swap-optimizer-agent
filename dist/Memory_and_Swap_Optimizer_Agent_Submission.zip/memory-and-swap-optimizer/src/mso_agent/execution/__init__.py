"""Command execution layer (fixed executables, shell=False, timeouts, output limits)."""
