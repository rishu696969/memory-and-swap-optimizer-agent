"""The only place in the project that starts external programs.

Rules enforced here:
* A command is chosen by a fixed key (e.g. "systemctl_show"); the executable
  is one of a few absolute paths -- PATH is never searched.
* Arguments are passed as a list with shell=False, so ';', '|', '$()' etc.
  have no special meaning.  Each argument is also checked by a per-command
  validator and the supplementary regex screen.
* Every run has a timeout (the whole process group is killed on expiry) and
  an output limit (extra bytes are read and discarded so the child never
  blocks, but memory use stays bounded).
* Privileged commands are prefixed with "sudo -n": sudo never prompts, so no
  password is ever typed into or captured by the agent.  If no sudo rule
  exists the command simply fails with a clear message.
"""

from __future__ import annotations

import os
import re
import signal
import subprocess
import threading
import time
from dataclasses import dataclass, field
from typing import Callable

from ..security import blacklist, policy

SAFE_ENV = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C", "LANG": "C"}
SUDO_CANDIDATES = ("/usr/bin/sudo", "/bin/sudo")


class CommandRejected(PermissionError):
    """The command or its arguments failed a policy check (nothing was run)."""


class CommandUnavailable(FileNotFoundError):
    """None of the fixed executable paths exists on this host."""


@dataclass(frozen=True)
class CommandSpec:
    key: str
    candidates: tuple[str, ...]                    # absolute paths only
    fixed_args: tuple[str, ...] = ()               # always placed before the variable args
    arg_validator: Callable[[list[str]], bool] = lambda args: not args
    privileged: bool = False
    timeout_s: float = policy.DEFAULT_TIMEOUT_S


@dataclass
class CommandResult:
    key: str
    argv: list[str]
    returncode: int | None
    stdout: str
    stderr: str
    timed_out: bool = False
    truncated: bool = False
    duration_s: float = 0.0
    dry_run: bool = False
    notes: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.returncode == 0 and not self.timed_out

    def as_dict(self) -> dict:
        return {
            "argv": self.argv,
            "returncode": self.returncode,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "timed_out": self.timed_out,
            "truncated": self.truncated,
            "duration_s": round(self.duration_s, 3),
            "dry_run": self.dry_run,
        }


_SYSCTL_SET_RE = re.compile(r"^vm\.(swappiness=(\d{1,3})|drop_caches=[123])$")
_UNIT_RE = policy.SERVICE_NAME_RE
_MOD_RE = policy.MODULE_NAME_RE


def _sysctl_set_ok(args: list[str]) -> bool:
    if len(args) != 1:
        return False
    m = _SYSCTL_SET_RE.fullmatch(args[0])
    if not m:
        return False
    if m.group(2) is not None:
        return policy.SWAPPINESS_MIN <= int(m.group(2)) <= policy.SWAPPINESS_MAX
    return True


def _one(regex: re.Pattern[str]) -> Callable[[list[str]], bool]:
    return lambda args: len(args) == 1 and bool(regex.fullmatch(args[0]))


# The complete list of programs the agent can ever run.
COMMANDS: dict[str, CommandSpec] = {
    # read-only
    "modinfo": CommandSpec("modinfo", ("/usr/sbin/modinfo", "/sbin/modinfo"), (), _one(_MOD_RE)),
    "systemctl_show": CommandSpec(
        "systemctl_show",
        ("/usr/bin/systemctl", "/bin/systemctl"),
        ("show", "--no-pager",
         "--property=Id,Description,LoadState,ActiveState,SubState,UnitFileState,MainPID,ActiveEnterTimestamp"),
        _one(_UNIT_RE),
    ),
    "sync": CommandSpec("sync", ("/usr/bin/sync", "/bin/sync"), timeout_s=30.0),
    # privileged, only reachable after a verified human approval
    "sysctl_set": CommandSpec(
        "sysctl_set", ("/usr/sbin/sysctl", "/sbin/sysctl"), ("-w",), _sysctl_set_ok, privileged=True
    ),
    "modprobe_load": CommandSpec(
        "modprobe_load", ("/usr/sbin/modprobe", "/sbin/modprobe"), (), _one(_MOD_RE), privileged=True
    ),
    "modprobe_remove": CommandSpec(
        "modprobe_remove", ("/usr/sbin/modprobe", "/sbin/modprobe"), ("-r",), _one(_MOD_RE), privileged=True
    ),
    "systemctl_restart": CommandSpec(
        "systemctl_restart", ("/usr/bin/systemctl", "/bin/systemctl"), ("restart",), _one(_UNIT_RE),
        privileged=True, timeout_s=60.0,
    ),
    "systemctl_enable": CommandSpec(
        "systemctl_enable", ("/usr/bin/systemctl", "/bin/systemctl"), ("enable",), _one(_UNIT_RE),
        privileged=True, timeout_s=60.0,
    ),
}


def _first_existing(paths: tuple[str, ...]) -> str | None:
    for p in paths:
        if os.path.isabs(p) and os.path.isfile(p) and os.access(p, os.X_OK):
            return p
    return None


def build_argv(key: str, args: list[str]) -> list[str]:
    """Map a command key + validated args to a full argv.  Raises on any policy failure."""
    spec = COMMANDS.get(key)
    if spec is None:
        raise CommandRejected(f"command '{key}' is not in the fixed command table")
    if not isinstance(args, list) or len(args) > policy.MAX_ARGS:
        raise CommandRejected("arguments must be a short list")
    for a in args:
        if not isinstance(a, str) or not a or len(a) > policy.MAX_ARG_LEN or "\x00" in a:
            raise CommandRejected(f"invalid argument {a!r}")
        if a.startswith("-"):
            raise CommandRejected(f"option-like argument {a!r} is not allowed")
    if not spec.arg_validator(args):
        raise CommandRejected(f"arguments {args!r} are not allowed for '{key}'")
    exe = _first_existing(spec.candidates)
    if exe is None:
        raise CommandUnavailable(f"'{key}' is not available on this host (looked for {list(spec.candidates)})")
    argv = [exe, *spec.fixed_args, *args]
    if spec.privileged:
        sudo = _first_existing(SUDO_CANDIDATES)
        if sudo is None:
            raise CommandUnavailable("sudo is not installed; privileged actions cannot run")
        argv = [sudo, "-n", *argv]
    reason = blacklist.screen_argv(argv)
    if reason:
        raise CommandRejected(f"blocked by supplementary screen: {reason}")
    return argv


def _bounded_reader(stream, limit: int, sink: list[bytes], flags: dict) -> None:
    kept = 0
    while True:
        chunk = stream.read(4096)
        if not chunk:
            break
        if kept < limit:
            take = chunk[: limit - kept]
            sink.append(take)
            kept += len(take)
            if len(take) < len(chunk):
                flags["truncated"] = True
        else:
            flags["truncated"] = True  # keep draining so the child does not block on a full pipe


def run_argv(argv: list[str], timeout_s: float, output_limit: int = policy.DEFAULT_OUTPUT_LIMIT, key: str = "") -> CommandResult:
    """Run an already-validated argv with timeout and output limit (shell=False)."""
    timeout_s = max(0.1, min(timeout_s, policy.MAX_TIMEOUT_S))
    start = time.monotonic()
    proc = subprocess.Popen(
        argv,
        shell=False,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=SAFE_ENV,
        start_new_session=True,   # own process group, so a timeout kills children too
        close_fds=True,
    )
    out: list[bytes] = []
    err: list[bytes] = []
    flags = {"truncated": False}
    threads = [
        threading.Thread(target=_bounded_reader, args=(proc.stdout, output_limit, out, flags), daemon=True),
        threading.Thread(target=_bounded_reader, args=(proc.stderr, output_limit, err, flags), daemon=True),
    ]
    for t in threads:
        t.start()
    timed_out = False
    try:
        proc.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        timed_out = True
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        proc.wait()
    for t in threads:
        t.join(timeout=2)
    return CommandResult(
        key=key,
        argv=argv,
        returncode=None if timed_out else proc.returncode,
        stdout=b"".join(out).decode("utf-8", "replace"),
        stderr=b"".join(err).decode("utf-8", "replace"),
        timed_out=timed_out,
        truncated=flags["truncated"],
        duration_s=time.monotonic() - start,
    )


def run_command(key: str, args: list[str] | None = None, *, dry_run: bool = False,
                output_limit: int = policy.DEFAULT_OUTPUT_LIMIT) -> CommandResult:
    """Validate and run a command from the fixed table."""
    args = list(args or [])
    argv = build_argv(key, args)
    spec = COMMANDS[key]
    if dry_run and spec.privileged:
        return CommandResult(key=key, argv=argv, returncode=0, stdout="", stderr="", dry_run=True,
                             notes=["dry-run: command was not executed"])
    return run_argv(argv, spec.timeout_s, output_limit, key=key)
