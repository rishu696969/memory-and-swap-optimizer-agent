"""Strict argument validation for every MCP tool.

The MCP SDK already derives a JSON schema from the type hints, but its pydantic
validation is lenient: it converts "3" to 3, True to 1 and silently ignores
unknown keys such as {"approved": true}.  This module is therefore the real
argument boundary.  It runs on the server *before* any tool code and:

* rejects unknown tool names and unknown argument keys,
* rejects wrong JSON types (no string->int or bool->int coercion),
* enforces numeric ranges, string lengths, choices and name patterns.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from . import policy


class ValidationError(ValueError):
    """Raised when a tool call is rejected before execution."""


@dataclass(frozen=True)
class Param:
    kind: type                      # int, float, str or bool
    required: bool = False
    minimum: float | None = None
    maximum: float | None = None
    choices: tuple[Any, ...] | None = None
    max_len: int = 256


# One entry per tool.  A tool missing from this table cannot be called.
TOOL_SPECS: dict[str, dict[str, Param]] = {
    # Memory and swap (primary module) -- read-only
    "get_memory_stats": {},
    "get_top_memory_processes": {"limit": Param(int, minimum=1, maximum=policy.TOP_PROCESSES_MAX)},
    "sample_process_memory": {
        "pid": Param(int, minimum=1, maximum=4_194_304),
        "top_n": Param(int, minimum=1, maximum=5),
        "samples": Param(int, minimum=policy.SAMPLES_MIN, maximum=policy.SAMPLES_MAX),
        "interval_seconds": Param(float, minimum=policy.INTERVAL_MIN_S, maximum=policy.INTERVAL_MAX_S),
        "growth_threshold_mb": Param(
            float, minimum=policy.GROWTH_THRESHOLD_MIN_MB, maximum=policy.GROWTH_THRESHOLD_MAX_MB
        ),
    },
    "get_swap_info": {},
    "recommend_memory_actions": {
        "window_seconds": Param(int, minimum=policy.WINDOW_MIN_S, maximum=policy.WINDOW_MAX_S)
    },
    # Memory and swap -- state changing (only create an approval request)
    "request_swappiness_change": {
        "value": Param(int, required=True, minimum=policy.SWAPPINESS_MIN, maximum=policy.SWAPPINESS_MAX)
    },
    "request_drop_caches": {"level": Param(int, required=True, choices=policy.DROP_CACHES_LEVELS)},
    # File integrity
    "verify_file_baseline": {"directory": Param(str, required=True, max_len=policy.MAX_PATH_LEN)},
    "list_file_baselines": {},
    "request_baseline_creation": {"directory": Param(str, required=True, max_len=policy.MAX_PATH_LEN)},
    # Kernel modules
    "list_kernel_modules": {"name_filter": Param(str, max_len=56)},
    "get_kernel_module_info": {"module": Param(str, required=True, max_len=64)},
    "request_module_action": {
        "module": Param(str, required=True, max_len=64),
        "action": Param(str, required=True, choices=policy.MODULE_ACTIONS),
    },
    # systemd services
    "get_service_status": {"service": Param(str, required=True, max_len=128)},
    "request_service_action": {
        "service": Param(str, required=True, max_len=128),
        "action": Param(str, required=True, choices=policy.SERVICE_ACTIONS),
    },
    # Host-only approval tools (never offered to the model)
    "apply_approved_change": {
        "op_id": Param(str, required=True, max_len=64),
        "approval_token": Param(str, required=True, max_len=128),
    },
    "cancel_pending_change": {"op_id": Param(str, required=True, max_len=64)},
}


def _check_type(name: str, value: Any, spec: Param) -> Any:
    # bool is a subclass of int in Python, so it must be rejected explicitly.
    if isinstance(value, bool) and spec.kind is not bool:
        raise ValidationError(f"argument '{name}' must be {spec.kind.__name__}, got boolean")
    if spec.kind is float:
        if not isinstance(value, (int, float)):
            raise ValidationError(f"argument '{name}' must be a number")
        value = float(value)
        if value != value or value in (float("inf"), float("-inf")):
            raise ValidationError(f"argument '{name}' must be finite")
        return value
    if not isinstance(value, spec.kind):
        raise ValidationError(
            f"argument '{name}' must be {spec.kind.__name__}, got {type(value).__name__}"
        )
    return value


def validate_arguments(tool: str, arguments: Any) -> dict[str, Any]:
    """Validate a raw tool call.  Returns a clean copy of the arguments."""
    if tool not in TOOL_SPECS:
        raise ValidationError(f"unknown tool '{tool}'")
    if arguments is None:
        arguments = {}
    if not isinstance(arguments, dict):
        raise ValidationError("arguments must be a JSON object")
    spec = TOOL_SPECS[tool]
    unknown = sorted(set(arguments) - set(spec))
    if unknown:
        raise ValidationError(f"unknown argument(s) for {tool}: {', '.join(unknown)}")
    clean: dict[str, Any] = {}
    for name, p in spec.items():
        if name not in arguments or arguments[name] is None:
            if p.required:
                raise ValidationError(f"missing required argument '{name}'")
            continue
        value = _check_type(name, arguments[name], p)
        if isinstance(value, str):
            if len(value) > p.max_len:
                raise ValidationError(f"argument '{name}' is too long")
            if "\x00" in value or any(ord(c) < 32 for c in value):
                raise ValidationError(f"argument '{name}' contains control characters")
        if p.minimum is not None and value < p.minimum:
            raise ValidationError(f"argument '{name}' must be >= {p.minimum}")
        if p.maximum is not None and value > p.maximum:
            raise ValidationError(f"argument '{name}' must be <= {p.maximum}")
        if p.choices is not None and value not in p.choices:
            raise ValidationError(f"argument '{name}' must be one of {list(p.choices)}")
        clean[name] = value
    return clean


# --- Domain validators used by the tool modules ---------------------------

def validate_module_name(name: str, allowlist: list[str] | None = None) -> str:
    """Normalise and check a kernel module name; optionally require the allowlist."""
    if name.startswith("-"):
        raise ValidationError(f"invalid kernel module name {name!r}")
    normalised = name.strip().replace("-", "_")
    if not policy.MODULE_NAME_RE.fullmatch(normalised):
        raise ValidationError(f"invalid kernel module name {name!r}")
    if allowlist is not None:
        allowed = {m.replace("-", "_") for m in allowlist}
        if normalised not in allowed:
            raise ValidationError(
                f"module '{normalised}' is not in the approved allowlist {sorted(allowed)}"
            )
    return normalised


def validate_service_name(name: str, allowlist: list[str] | None = None) -> str:
    """Check a systemd unit name (".service" is appended if missing)."""
    unit = name.strip()
    if not unit.endswith(".service"):
        unit += ".service"
    if not policy.SERVICE_NAME_RE.fullmatch(unit):
        raise ValidationError(f"invalid service name {name!r}")
    if allowlist is not None and unit not in set(allowlist):
        raise ValidationError(f"service '{unit}' is not in the approved allowlist {sorted(allowlist)}")
    return unit


def validate_directory(path: str, allowed_roots: list[str]) -> Path:
    """Resolve *path* and require it to be an existing directory inside an allowed root.

    realpath() resolves symlinks and '..' first, so 'allowed/../../etc' or a
    symlink pointing outside the root is rejected.
    """
    if not path or len(path) > policy.MAX_PATH_LEN or "\x00" in path:
        raise ValidationError("invalid directory path")
    expanded = os.path.expanduser(path)
    if not os.path.isabs(expanded):
        raise ValidationError("directory must be an absolute path (or start with ~)")
    real = os.path.realpath(expanded)
    for prefix in policy.FORBIDDEN_PATH_PREFIXES:
        if real == prefix or real.startswith(prefix + os.sep):
            raise ValidationError(f"directory under {prefix} is not allowed")
    roots = [os.path.realpath(os.path.expanduser(r)) for r in allowed_roots]
    if not any(real == r or os.path.commonpath([real, r]) == r for r in roots):
        raise ValidationError(f"directory {real} is outside the allowed roots {roots}")
    if not os.path.isdir(real):
        raise ValidationError(f"directory {real} does not exist")
    return Path(real)
