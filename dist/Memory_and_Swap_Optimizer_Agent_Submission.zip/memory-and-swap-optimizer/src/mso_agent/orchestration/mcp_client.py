"""MCP client side: start the tool server as a subprocess and talk to it over stdio.

This is a real MCP connection (JSON-RPC over the server's stdin/stdout) using
the official SDK's `Client` + `StdioServerParameters`.  Only MSO_* settings and
the approval key are passed to the server -- API keys are not.
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from typing import Any

from mcp import Client, StdioServerParameters
from mcp.types import TextContent

from ..config import SERVER_ENV_KEYS


@dataclass
class ToolInfo:
    name: str
    description: str
    input_schema: dict[str, Any]
    read_only: bool


@dataclass
class ToolOutcome:
    ok: bool
    data: Any            # structured_content when the tool succeeded
    error: str | None    # error text when is_error is true


class ToolServerConnection:
    """Async context manager wrapping one MCP stdio session."""

    def __init__(self, approval_key: bytes, extra_env: dict[str, str] | None = None):
        env = {k: os.environ[k] for k in SERVER_ENV_KEYS if k in os.environ}
        env.update(extra_env or {})
        env["MSO_APPROVAL_KEY"] = approval_key.hex()
        self.params = StdioServerParameters(command=sys.executable, args=["-m", "mso_agent.server"], env=env)
        self._client: Client | None = None
        self.tools: list[ToolInfo] = []

    async def __aenter__(self) -> "ToolServerConnection":
        self._client = Client(self.params)
        await self._client.__aenter__()
        listed = await self._client.list_tools()
        self.tools = [
            ToolInfo(
                name=t.name,
                description=t.description or "",
                input_schema=t.input_schema,
                read_only=bool(t.annotations and t.annotations.read_only_hint),
            )
            for t in listed.tools
        ]
        return self

    async def __aexit__(self, *exc) -> None:
        if self._client is not None:
            await self._client.__aexit__(*exc)
            self._client = None

    async def call(self, name: str, arguments: dict[str, Any]) -> ToolOutcome:
        assert self._client is not None, "connection not open"
        result = await self._client.call_tool(name, arguments)
        text = " ".join(b.text for b in result.content if isinstance(b, TextContent))
        if result.is_error:
            return ToolOutcome(ok=False, data=None, error=text or "tool failed")
        data = result.structured_content
        if isinstance(data, dict) and set(data) == {"result"}:
            data = data["result"]          # SDK wraps non-object return values as {"result": ...}
        return ToolOutcome(ok=True, data=data if data is not None else text, error=None)
