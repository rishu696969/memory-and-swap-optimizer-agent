"""LLM providers behind one small interface.

    reply = await provider.chat(messages, tools)

`messages` use the OpenAI chat format (system/user/assistant/tool).  `tools` is
the list discovered from the MCP server.  The reply is either text or a list of
tool calls.  Three providers exist:

* OllamaProvider - local model through Ollama's /api/chat (default).
* OpenAIProvider - OpenAI Chat Completions; needs OPENAI_API_KEY.
* DemoRouter     - deterministic keyword routing in demo_router.py; NOT an LLM.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from typing import Any, Protocol

import httpx

from .mcp_client import ToolInfo


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict[str, Any]
    parse_error: str | None = None   # set when the model produced malformed JSON


@dataclass
class LLMReply:
    text: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)


class Provider(Protocol):
    name: str
    is_llm: bool

    async def chat(self, messages: list[dict], tools: list[ToolInfo]) -> LLMReply: ...


def tool_specs(tools: list[ToolInfo]) -> list[dict]:
    """MCP tool list -> the function-calling format both Ollama and OpenAI accept."""
    return [
        {"type": "function",
         "function": {"name": t.name, "description": t.description, "parameters": t.input_schema}}
        for t in tools
    ]


def _parse_args(raw: Any) -> tuple[dict, str | None]:
    if isinstance(raw, dict):
        return raw, None
    if raw in (None, ""):
        return {}, None
    try:
        value = json.loads(raw)
    except (TypeError, json.JSONDecodeError) as exc:
        return {}, f"arguments were not valid JSON: {exc}"
    return (value, None) if isinstance(value, dict) else ({}, "arguments must be a JSON object")


class OllamaProvider:
    name = "ollama"
    is_llm = True

    def __init__(self, host: str, model: str, timeout_s: float = 120.0, transport: httpx.AsyncBaseTransport | None = None):
        self.host, self.model, self.timeout_s, self._transport = host.rstrip("/"), model, timeout_s, transport

    def _to_ollama(self, messages: list[dict]) -> list[dict]:
        out = []
        for m in messages:
            if m["role"] == "assistant" and m.get("tool_calls"):
                out.append({"role": "assistant", "content": m.get("content") or "",
                            "tool_calls": [{"function": {"name": c["function"]["name"],
                                                         "arguments": json.loads(c["function"]["arguments"])}}
                                           for c in m["tool_calls"]]})
            elif m["role"] == "tool":
                out.append({"role": "tool", "content": m["content"], "tool_name": m.get("name", "")})
            else:
                out.append({"role": m["role"], "content": m.get("content") or ""})
        return out

    async def chat(self, messages: list[dict], tools: list[ToolInfo]) -> LLMReply:
        payload = {"model": self.model, "messages": self._to_ollama(messages), "tools": tool_specs(tools),
                   "stream": False, "options": {"temperature": 0}}
        async with httpx.AsyncClient(timeout=self.timeout_s, transport=self._transport) as client:
            resp = await client.post(f"{self.host}/api/chat", json=payload)
            resp.raise_for_status()
            msg = resp.json().get("message", {})
        calls = []
        for c in msg.get("tool_calls") or []:
            fn = c.get("function", {})
            args, err = _parse_args(fn.get("arguments"))
            calls.append(ToolCall(id="call_" + uuid.uuid4().hex[:8], name=fn.get("name", ""), arguments=args,
                                  parse_error=err))
        return LLMReply(text=msg.get("content") or "", tool_calls=calls)


class OpenAIProvider:
    name = "openai"
    is_llm = True

    def __init__(self, model: str, timeout_s: float = 120.0, client: Any = None):
        if client is None:
            from openai import AsyncOpenAI   # optional dependency; reads OPENAI_API_KEY itself
            client = AsyncOpenAI(timeout=timeout_s)
        self.model, self.client = model, client

    @staticmethod
    def _to_openai(messages: list[dict]) -> list[dict]:
        out = []
        for m in messages:
            if m["role"] == "tool":
                out.append({"role": "tool", "tool_call_id": m["tool_call_id"], "content": m["content"]})
            else:
                out.append({k: v for k, v in m.items() if k in ("role", "content", "tool_calls")})
        return out

    async def chat(self, messages: list[dict], tools: list[ToolInfo]) -> LLMReply:
        resp = await self.client.chat.completions.create(
            model=self.model, messages=self._to_openai(messages), tools=tool_specs(tools), temperature=0,
        )
        msg = resp.choices[0].message
        calls = []
        for c in msg.tool_calls or []:
            args, err = _parse_args(c.function.arguments)
            calls.append(ToolCall(id=c.id, name=c.function.name, arguments=args, parse_error=err))
        return LLMReply(text=msg.content or "", tool_calls=calls)


def make_provider(settings) -> Provider:
    from .demo_router import DemoRouter

    if settings.provider == "demo":
        return DemoRouter()
    if settings.provider == "ollama":
        return OllamaProvider(settings.ollama_host, settings.ollama_model, settings.llm_timeout_s)
    if settings.provider == "openai":
        return OpenAIProvider(settings.openai_model, settings.llm_timeout_s)
    raise ValueError(f"unknown provider {settings.provider!r} (use demo, ollama or openai)")
