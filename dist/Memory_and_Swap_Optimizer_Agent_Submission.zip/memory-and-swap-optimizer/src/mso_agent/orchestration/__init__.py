"""Orchestration layer: LLM providers, MCP client and the agent loop."""
