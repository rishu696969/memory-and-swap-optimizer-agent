"""DEMO ROUTING - deterministic keyword rules, NOT LLM inference.

Used when no model is available (no API key, Ollama not running) so that the
whole pipeline -- MCP client, MCP server, validation, approval gate, command
runner, audit log -- can still be demonstrated and tested reproducibly.  It
produces the same kind of tool calls a model would, then formats the tool
results with fixed templates.  Every answer is labelled so nobody mistakes it
for model output.
"""

from __future__ import annotations

import re
import uuid
from typing import Any

from .mcp_client import ToolInfo
from .providers import LLMReply, ToolCall

DEMO_LABEL = "[demo routing: deterministic keyword rules, no LLM inference]"

PATH_RE = re.compile(r"(~?/[^\s'\"]+)")
NUM_RE = re.compile(r"\b(\d{1,4})\b")
SERVICE_RE = re.compile(r"\b([A-Za-z0-9][A-Za-z0-9:_.@-]*\.service)\b")
WORD_AFTER_RE = r"\b{verb}\s+(?:the\s+)?([A-Za-z0-9][A-Za-z0-9:_.@-]*)"


def _call(name: str, **args: Any) -> ToolCall:
    return ToolCall(id="demo_" + uuid.uuid4().hex[:8], name=name, arguments=args)


def route(text: str) -> list[ToolCall]:
    """Map one user request to zero or more tool calls."""
    t = text.lower()
    calls: list[ToolCall] = []
    path = PATH_RE.search(text)

    # ---- file integrity ---------------------------------------------------
    if path and re.search(r"\b(verify|check)\b", t) and not ("service" in t or "module" in t):
        return [_call("verify_file_baseline", directory=path.group(1))]
    if "baseline" in t or "integrity" in t or "hash" in t:
        if "list" in t and not path:
            return [_call("list_file_baselines")]
        if not path:
            return []
        if any(w in t for w in ("verify", "check", "compare", "changed", "modified")):
            return [_call("verify_file_baseline", directory=path.group(1))]
        return [_call("request_baseline_creation", directory=path.group(1))]

    # ---- kernel modules -----------------------------------------------------
    if "webcam" in t or "camera" in t:
        return [_call("request_module_action", module="uvcvideo", action="reload")]
    if "module" in t or "driver" in t:
        m = re.search(r"\b(reload|unload|load|info(?:rmation)?\s+(?:about|for|on))\s+(?:the\s+)?(?:module\s+)?([a-z0-9_\-]+)", t)
        if m and m.group(1).startswith("info"):
            return [_call("get_kernel_module_info", module=m.group(2))]
        if m:
            return [_call("request_module_action", module=m.group(2), action=m.group(1))]
        f = re.search(r"\b(?:matching|named|containing|filter)\s+([a-z0-9_\-]+)", t)
        return [_call("list_kernel_modules", **({"name_filter": f.group(1)} if f else {}))]

    # ---- systemd services ---------------------------------------------------
    if "service" in t or "restart" in t or "systemd" in t or "on boot" in t:
        svc = SERVICE_RE.search(text)
        name = svc.group(1) if svc else None
        if name is None:
            m = re.search(WORD_AFTER_RE.format(verb="(?:restart|enable|status of|check)"), t)
            name = m.group(1) if m else None
        if name is None:
            return []
        if "restart" in t:
            calls.append(_call("request_service_action", service=name, action="restart"))
        if "enable" in t or "on boot" in t or "starts on boot" in t:
            calls.append(_call("request_service_action", service=name, action="enable"))
        return calls or [_call("get_service_status", service=name)]

    # ---- memory and swap (primary module) -------------------------------------
    if "swappiness" in t:
        m = re.search(r"\b(?:to|=)\s*(\d{1,4})\b", t)
        if m and any(w in t for w in ("set", "change", "lower", "raise", "make")):
            return [_call("request_swappiness_change", value=int(m.group(1)))]
        return [_call("get_swap_info")]
    if "drop" in t and "cache" in t:
        m = re.search(r"level\s*(\d)", t)
        if m:
            return [_call("request_drop_caches", level=int(m.group(1)))]
    wants_top = "top" in t or "process" in t or "using the most" in t or "hog" in t
    if any(w in t for w in ("lag", "slow", "free up", "ram", "memory", "cache", "optimi", "recommend")) and not (
            wants_top and not any(w in t for w in ("lag", "slow", "free up"))):
        calls.append(_call("get_memory_stats"))
        if any(w in t for w in ("lag", "slow", "free up", "optimi", "recommend", "cache")):
            calls.append(_call("recommend_memory_actions", window_seconds=2))
    if wants_top:
        n = NUM_RE.search(t)
        calls.append(_call("get_top_memory_processes", limit=min(int(n.group(1)), 25) if n else 5))
    if "leak" in t or "growing" in t or "growth" in t:
        pid = re.search(r"\bpid\s*(\d+)", t)
        args: dict[str, Any] = {"samples": 6, "interval_seconds": 1.0, "growth_threshold_mb": 5.0}
        if pid:
            args["pid"] = int(pid.group(1))
        calls.append(_call("sample_process_memory", **args))
    if "swap" in t and not any(c.name == "get_swap_info" for c in calls):
        calls.append(_call("get_swap_info"))
    # remove duplicates while keeping order
    seen, unique = set(), []
    for c in calls:
        if c.name not in seen:
            seen.add(c.name)
            unique.append(c)
    return unique


# ---------------------------------------------------------------------------
# Deterministic formatting of tool results
# ---------------------------------------------------------------------------

def _fmt_memory(d: dict) -> list[str]:
    return [
        f"RAM: {d['total_mb']} MB total, {d['available_mb']} MB available ({d['available_percent']}%), "
        f"{d['free_mb']} MB completely free, {d['page_cache_mb']} MB page cache.",
        f"Swap: {d['swap_used_mb']} of {d['swap_total_mb']} MB used.",
        f"Memory pressure: {d['pressure_level'].upper()} - " + "; ".join(d["pressure_reasons"]),
        d["explanation"],
    ]


def _fmt_recommend(d: dict) -> list[str]:
    lines = [f"Recommendations (pressure {d['pressure_level']}):"]
    for r in d["recommendations"]:
        lines.append(f"  [{r['severity']}] {r['title']}: {r['advice']}")
    lines.append(d["disclaimer"])
    return lines


def _fmt_top(d: dict) -> list[str]:
    lines = [f"Top {d['count']} processes by resident memory:"]
    for p in d["processes"]:
        lines.append(f"  pid {p['pid']:>7}  {p['rss_mb']:>9} MB  {p['percent_of_ram']:>5}%  {p['name']}")
    return lines


def _fmt_sampling(d: dict) -> list[str]:
    lines = [f"Sampled {len(d['results'])} process(es) {d['samples']} times every {d['interval_seconds']} s:"]
    for r in d["results"]:
        lines.append(f"  pid {r['pid']} {r['name']}: {r['verdict']}")
    lines.append(d["disclaimer"])
    return lines


def _fmt_swap(d: dict) -> list[str]:
    devs = ", ".join(f"{x['name']} ({x['used_mb']}/{x['size_mb']} MB)" for x in d["devices"]) or "none"
    return [f"Swap devices: {devs}. vm.swappiness = {d['swappiness']}.", d["explanation"]]


def _fmt_change(d: dict) -> list[str]:
    status = d.get("status")
    if status == "approval_required":
        return [f"Approval requested: {d['summary']}"]
    if status == "denied_by_user":
        return [f"Not executed - the human declined: {d['summary']}"]
    if "result" not in d:
        return []
    r = d["result"] if isinstance(d["result"], dict) else {}
    lines = [f"Change {d['action']} {d['arguments']}: {str(status).upper()}."]
    commands = [r["command"]] if r.get("command") else list(r.get("steps") or [])
    for c in commands:
        lines.append(f"  command: {' '.join(c['argv'])} -> exit {c['returncode']}"
                     + (" (dry-run, not executed)" if c.get("dry_run") else ""))
        if c.get("stderr", "").strip():
            lines.append(f"  stderr: {c['stderr'].strip()[:300]}")
    if r.get("error"):
        lines.append(f"  error: {r['error']}")
    for key in ("swappiness_before", "swappiness_after", "verified", "measured_before", "measured_after",
                "file_count", "store_file", "loaded_after", "restore_instructions", "note"):
        if r.get(key) is not None:
            lines.append(f"  {key}: {r[key]}")
    return lines


def _fmt_modules(d: dict) -> list[str]:
    if not d["available"]:
        return [d["note"]]
    lines = [f"{d['count']} loaded kernel module(s):"]
    for m in d["modules"][:40]:
        lines.append(f"  {m['name']:<20} {m['size_bytes']:>8} bytes  refcount {m['used_by_count'] if m['used_by_count'] is not None else '-'}  {m['state']}")
    return lines + ([d["note"]] if d.get("note") else [])


def _fmt_service(d: dict) -> list[str]:
    if not d.get("available"):
        return [f"Status of {d['service']} unavailable: {d.get('stderr') or d.get('error')}", d.get("hint", "")]
    p = d["properties"]
    return [f"{d['service']}: {p.get('ActiveState')} ({p.get('SubState')}), load={p.get('LoadState')}, "
            f"unit file={p.get('UnitFileState')}. {d.get('hint', '')}"]


def _fmt_modinfo(d: dict) -> list[str]:
    if not d["found"]:
        return [f"modinfo {d['module']}: not found ({d['stderr']})"]
    return [f"modinfo {d['module']}:"] + [f"  {k}: {v}" for k, v in d["fields"].items()]


def _fmt_verify(d: dict) -> list[str]:
    return [f"Integrity check of {d['directory']} (baseline {d['baseline_created_at']}): {d['status']}.",
            f"  modified: {d['modified'] or 'none'}", f"  missing: {d['missing'] or 'none'}",
            f"  new: {d['new'] or 'none'}"]


FORMATTERS = {
    "get_memory_stats": _fmt_memory,
    "recommend_memory_actions": _fmt_recommend,
    "get_top_memory_processes": _fmt_top,
    "sample_process_memory": _fmt_sampling,
    "get_swap_info": _fmt_swap,
    "verify_file_baseline": _fmt_verify,
    "list_kernel_modules": _fmt_modules,
    "get_service_status": _fmt_service,
    "get_kernel_module_info": _fmt_modinfo,
}


def summarize(tool_messages: list[dict]) -> str:
    lines: list[str] = []
    for m in tool_messages:
        name, data, error = m.get("name"), m.get("_data"), m.get("_error")
        if error:
            lines.append(f"{name} failed: {error}")
            continue
        fmt = FORMATTERS.get(name)
        if fmt and isinstance(data, dict):
            lines.extend(fmt(data))
        elif isinstance(data, list) and name == "list_file_baselines":
            lines.append(f"{len(data)} stored baseline(s):")
            lines.extend(f"  {b['directory']} ({b['file_count']} files, {b['created_at']})" for b in data)
        elif isinstance(data, dict) and (data.get("status") or data.get("action")):
            lines.extend(_fmt_change(data) or [f"{name}: {data}"])
        else:
            text = str(data)
            lines.append(f"{name}: {text[:1500]}")
    return "\n".join(lines)


class DemoRouter:
    name = "demo"
    is_llm = False

    async def chat(self, messages: list[dict], tools: list[ToolInfo]) -> LLMReply:
        last = messages[-1]
        if last["role"] == "user":
            calls = route(last["content"])
            if not calls:
                return LLMReply(text=f"{DEMO_LABEL}\nI could not map that request to a tool. Try: 'my computer "
                                     "is lagging', 'show top 5 processes', 'check for memory leaks', 'show swap "
                                     "info', 'set swappiness to 30', 'create a baseline for ~/dir', 'verify "
                                     "~/dir', 'list kernel modules', 'status of cron.service'.")
            return LLMReply(tool_calls=calls)
        # After tool results: format everything since the last user message.
        tail = []
        for m in reversed(messages):
            if m["role"] == "user":
                break
            if m["role"] == "tool":
                tail.append(m)
        return LLMReply(text=f"{DEMO_LABEL}\n" + summarize(list(reversed(tail))))
