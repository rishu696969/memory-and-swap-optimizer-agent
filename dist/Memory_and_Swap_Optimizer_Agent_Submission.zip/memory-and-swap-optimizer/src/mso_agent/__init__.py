"""Memory and Swap Optimizer Agent.

An LLM-assisted Linux administration agent built for the Operating System Lab
(BCSE303P).  The primary module inspects RAM and swap; supporting modules cover
file integrity, kernel modules and systemd services.  Every tool is exposed
through a real Model Context Protocol (MCP) server and every state-changing
action needs a human approval that is verified at the execution boundary.
"""

__version__ = "1.0.0"
