"""Allow `python -m mso_agent` to start the REPL."""

from .interface.repl import main

main()
